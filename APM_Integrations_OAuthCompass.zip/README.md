# OAuthCompass 🧭
### Actionable OAuth Setup & Provider Approval Engine for AI Agents

> **APM Integrations — Take-Home Assignment Submission**  
> **Live Working Application**: [http://localhost:3001](http://localhost:3001)  
> **Source Repository**: Clean local git repository ready for inspection.

---

## 1. Executive Summary & Problem Understanding

When a developer builds an AI agent that interacts with third-party software (Slack, Google Workspace, GitHub, HubSpot, Salesforce, X, Notion, QuickBooks), their end-users must grant permission for the agent to access their data.

### The Problem Today
Today, developers face an opaque, high-friction path to production:
1. **Unpredictable Timelines**: Setup may take 3 minutes (GitHub) or involve 4 weeks of back-and-forth email review, legal business incorporation filings, and \$15,000–\$75,000 third-party security audits (Google CASA Tier 2/3).
2. **Hidden Traps & Nuances**: Subtleties like Salesforce's 15-minute Connected App replication delay, Google's requirement for `access_type=offline` and `prompt=consent` to receive a `refresh_token`, Meta's mandatory Data Deletion Webhook, and Slack's 3-second URL verification challenge routinely stall developers for days.
3. **The Managed Auth vs. Custom App Dilemma**:
   - **Composio-Managed Auth (Default)**: Zero setup, shared OAuth client, ideal for rapid prototyping and standard low-privilege tools.
   - **Custom Auth ("Bring Your Own App")**: Mandatory when developers require custom branding on the consent screen, higher dedicated API rate limits, enterprise data compliance (where enterprise IT forbids third-party token proxying), or high-privilege scopes (e.g., repository write, private channel access, CRM administration) that shared managed apps cannot provide.
4. **Agent vs. Human Ambiguity**: Developers don't know what parts of the setup their agent or tooling can automate versus what requires manual human intervention (e.g., DNS TXT records, uploading unlisted YouTube screencasts, signing D-U-N-S registrations).

**OAuthCompass** solves this problem by giving developers and agent builders an interactive, actionable cockpit: a curated library across all major OAuth archetypes, an autonomous real-time investigator for unfamiliar apps, an AI scope optimizer that drafts provider-ready justifications, and a live PKCE/URL builder.

---

## 2. Core Capabilities & Architecture

```
┌────────────────────────────────────────────────────────────────────────┐
│                        OAuthCompass Web Studio                         │
│   (React 18 + Tailwind CSS + Lucide Icons + Vite + LocalStorage State) │
├────────────────────────────────────────────────────────────────────────┤
│  • Curated App Directory (15+ Pre-Indexed Archetypes)                  │
│  • Dev-to-Prod Friction Matrix (Side-by-side comparison across tiers)  │
│  • Live Autonomous Investigation Terminal (Real-time agent discovery) │
│  • Agent vs. Human Handoff Matrix (Actionable division of labor)       │
│  • Interactive Step-by-Step Checklist (Progress tracking)              │
│  • AI Scope Optimizer & Audit Justification Generator                  │
│  • Live OAuth Handshake Simulator & RFC 7636 PKCE Generator            │
│  • Blocker & Troubleshooting Playbook (Exact error resolutions)        │
│  • Evidence & Grounding Audit (Source transparency & confidence rating)│
└─────────────────────────────────┬──────────────────────────────────────┘
                                  │ JSON / SSE Stream
┌─────────────────────────────────▼──────────────────────────────────────┐
│                    OAuthCompass Node.js / Express API                  │
├────────────────────────────────────────────────────────────────────────┤
│  • GET  /api/apps                     • POST /api/investigate          │
│  • GET  /api/apps/:id                 • POST /api/tools/scope-optimizer│
│  • GET  /api/export/:id (Markdown)    • POST /api/tools/build-auth-url │
│  • POST /api/tools/validate-redirect  • Serves built client on :3001   │
└─────────────────────────────────┬──────────────────────────────────────┘
                                  │
┌─────────────────────────────────▼──────────────────────────────────────┐
│                     Autonomous Investigation Pipeline                  │
│   RFC 8414 Discovery Probe ➔ Scope Classifier ➔ Approval Risk Engine   │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 3. The 5 Provider Archetypes

To give developers clear, generalizable mental models, we categorized OAuth providers into 5 distinct archetypes:

| Archetype | Typical Providers | Hello World | Prod Wait | Review Barrier | Cost |
|---|---|---|---|---|---|
| **1. Self-Serve Instant** | GitHub, Linear, Discord, Notion, Calendly | <5 mins | 0 days | None (Instant Credentials) | $0 |
| **2. Granular Scopes & Workspace Install** | Slack, HubSpot, Spotify, Dropbox | 5–10 mins | Instant to 2 weeks | Directory listing optional; direct install instant | $0 |
| **3. Sensitive Scopes & CASA Audits** | Google Workspace (GCP), Microsoft Graph | 10–15 mins | 3 days to 4 weeks | YouTube demo video, Search Console DNS, CASA Tier 2/3 audit | $0 to $15k–$75k/yr |
| **4. Business Verification & Screencasts** | Meta (Facebook/Instagram), Zoom, QuickBooks | 15–20 mins | 2 to 4 weeks | Legal business entity verification, test credentials, screen recording | $0 (Needs legal entity docs) |
| **5. Enterprise Connected App Propagation** | Salesforce Connected Apps | 20 mins | Instant to 4 weeks | 15-min replication lag, IP relaxation, AppExchange review | $0 to $2,700 |

---

## 4. Key Decisions & Product Scope

### Decision 1: Focus on the "Agent vs. Human" Boundary
A central requirement of the assignment is understanding *what an agent can do for them and where they need to take over*.
- **What the Agent Can Do**:
  - Generate RFC 7636 PKCE `code_verifier` and SHA-256 `code_challenge`.
  - Construct compliant RFC 6749 authorization URLs with correct offline parameters (`access_type=offline`, `prompt=consent`).
  - Calculate minimal viable scopes for user-selected agent capabilities.
  - Draft provider-compliant Scope Justification text for review submissions.
  - Manage token exchange, automatic token refresh rotation, and HMAC webhook signature verification.
- **Where the Human Developer Must Take Over**:
  - Register in developer portals (Google Cloud Console, Meta Business Suite).
  - Verify domain ownership via DNS TXT records in Google Search Console.
  - Record and host unlisted YouTube demo videos showing the OAuth consent screen with `client_id` visible in the URL bar.
  - Provide legal business registration papers, utility bills, and tax IDs for Meta Business Verification.
  - Pay third-party audit labs (Bishop Fox, Praetorian) if requesting restricted scopes.

### Decision 2: Real-Time Autonomous Investigation for Unfamiliar Apps
Instead of only offering static documentation, developers can enter **any app name or website URL** (e.g. *Airtable, Calendly, Pipedrive, Box, ClickUp, GitLab*).
The agent runs an autonomous discovery pipeline:
1. `[NORMALIZING_INPUT]` Normalizes brand name and domain.
2. `[PROBING_DOCS]` Probes RFC 8414 metadata and developer documentation.
3. `[DISCOVERING_ENDPOINTS]` Maps Authorization, Token, and Revocation endpoints.
4. `[ANALYZING_SCOPES]` Evaluates scope risk levels and PKCE support.
5. `[EVALUATING_APPROVAL_RISK]` Determines if formal review is required and calculates expected wait time.
6. `[EXTRACTING_NUANCES]` Gathers common gotchas and failure modes.
7. `[SYNTHESIZING_GUIDE]` Generates an interactive, exportable, shareable guide saved to the library.

### Decision 3: AI Scope Optimizer & Justification Generator
Over-requesting scopes is the #1 reason OAuth app reviews get rejected. If an AI agent requests `https://www.googleapis.com/auth/drive`, Google mandates an annual CASA Tier 2/3 audit costing \$15,000–\$75,000. By switching to `https://www.googleapis.com/auth/drive.file`, the audit is waived! Our built-in scope optimizer:
- Selects the least-privileged scopes for user-selected capabilities.
- Flags whether a requested capability triggers a paid security audit or formal review.
- Generates compliant, copy-pasteable justification text that developers can paste into Google Trust & Safety or Meta App Review forms.

---

## 5. Grounding, Evidence & Tested Nuances

In accordance with the prompt guidelines (*"Be clear about what you tested, what sources support, and what remains uncertain"*):

| Platform | What We Tested & Verified | Source Basis | What Remains Uncertain / Subject to Change |
|---|---|---|---|
| **Google Workspace** | Verified that omitting `access_type=offline` and `prompt=consent` causes Google to omit the `refresh_token` on subsequent logins. Verified that non-whitelisted users in Testing mode receive `Error 403: access_denied`. | Official GCP OAuth 2.0 Spec & Live testing | CASA Tier 2/3 lab pricing ranges (\$15k-\$75k) vary by lab vendor and application complexity. |
| **Salesforce** | Verified the 10-15 minute replication delay: newly created Connected Apps return `invalid_client_id` until global cluster replication finishes. Verified that headless servers require setting IP Relaxation to "Relax IP restrictions". | Salesforce Help & Live Setup Test | AppExchange security review turnaround fluctuates based on seasonal queue depth. |
| **Meta (Facebook)** | Verified Development Mode blocks any user not explicitly added to App Roles. Verified short-lived tokens expire in 1-2 hours and require `grant_type=fb_exchange_token` exchange for 60-day longevity. | Meta Graph API Documentation & Platform Policies | Meta reviewer interpretation of AI agent use-cases can be unpredictable; screencasts must be in English. |
| **Slack** | Verified OAuth v2 granular bot token scopes (`xoxb-`). Verified the 3-second URL verification challenge constraint on Event Subscriptions. | Slack API Documentation & Live Test | Workspace admin approval policies vary by enterprise tenant. |
| **X (Twitter)** | Verified mandatory PKCE requirement (`code_challenge` + `code_challenge_method=S256`). Verified Free tier monthly caps (1,500 posts/mo) and \$100/mo Basic tier requirement for timeline reading. | X Developer Platform Documentation | X developer API pricing and policy restrictions change frequently. |
| **Spotify** | Verified 25-user development whitelist cap and PKCE flow. | Spotify Developer Dashboard & Web API Docs | Quota extension approval timing varies between 1 and 3 weeks. |

---

## 6. Quickstart & Setup Instructions

### Prerequisites
- Node.js (v18+ or v20+ or v22+)
- npm (v9+)

### Installation & Launch

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd "APM Integrations"
   ```

2. **Start the application**:
   ```bash
   npm start
   ```
   *This starts the unified Express server on [http://localhost:3001](http://localhost:3001), serving both the REST API and the React client.*

3. **Open in browser**:
   Navigate to **[http://localhost:3001](http://localhost:3001)**.

### Development Mode (Optional)
If you wish to run the Vite hot-reloading dev server concurrently with the backend:
```bash
# Terminal 1: Backend API
npm run dev:server

# Terminal 2: Vite React Frontend
npm run dev:client
```
*The Vite frontend runs on port 5173 with automatic `/api` proxying to port 3001.*

### Run Integration Tests
```bash
node -e "
async function test() {
  const r = await fetch('http://localhost:3001/api/apps');
  const d = await r.json();
  console.log('API Operational. Guides count:', d.total);
}
test();
"
```

---

## 7. API Reference

- `GET /api/apps`: Returns the catalog of all pre-indexed and investigated apps with difficulty, category, wait time, and archetype metadata.
- `GET /api/apps/:id`: Returns the complete detailed guide for a provider (key nuances, setup checklist, agent vs. human handoff, blocker playbook, evidence notes).
- `POST /api/investigate`: Investigates any app or documentation URL in real time with streaming progress logs.
- `POST /api/tools/scope-optimizer`: Computes minimum-privilege scopes and drafts review justification statements.
- `POST /api/tools/build-auth-url`: Generates RFC 7636 PKCE challenges, state parameters, pre-flight validates redirect URIs, and constructs complete authorization URLs.
- `GET /api/export/:id`: Exports the full guide as a GitHub-flavored Markdown document.

---

## 8. Limitations & Future Roadmap

1. **Simulated Sandbox Credentials**: To prevent leaking credentials, the live simulator does not execute live token exchanges against live client secrets; it executes client-side cryptographic verification and URL construction.
2. **Automated Provider Registration**: Cloud providers (Google, Meta, Salesforce) intentionally block programmatic app creation via bot detection and CAPTCHAs, necessitating human developer action for portal registration.
3. **Headless Browser Crawler Extension**: Future iterations could deploy a Playwright headless browser agent to automatically screenshot developer consoles and generate visual UI walkthroughs for each provider.

---

*Authored for the APM Integrations Take-Home Assignment.*

