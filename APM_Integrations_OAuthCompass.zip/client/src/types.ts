export interface ScopeItem {
  name: string;
  description: string;
  riskLevel: 'none' | 'low' | 'medium' | 'high' | 'critical';
  reviewTrigger: boolean;
  recommendedForAgents: boolean;
  sampleJustification: string;
}

export interface SetupStep {
  id: string;
  stepNumber: number;
  title: string;
  description: string;
  agentSupport: 'Automated' | 'Assisted' | 'Manual';
  estimatedMinutes: number;
  copyableSnippet: string | null;
  docsUrl: string | null;
}

export interface BlockerItem {
  error: string;
  cause: string;
  solution: string;
}

export interface AgentVsHumanMatrix {
  agentCapabilities: string[];
  humanRequirements: string[];
}

export interface OAuthEndpoints {
  authorizationUrl: string;
  tokenUrl: string;
  revocationUrl: string | null;
  userInfoUrl: string | null;
  pkceSupported: boolean;
  responseType: string;
}

export interface EvidenceInfo {
  officialDocsUrl: string;
  lastVerifiedDate: string;
  verifiedVia: string;
  confidence: string;
  notes: string;
}

export interface AppProfile {
  id: string;
  name: string;
  category: string;
  website: string;
  developerPortal: string;
  authType: string;
  difficulty: number;
  difficultyLabel: string;
  timeToHelloWorld: string;
  timeToProductionApproval: string;
  approvalRequired: boolean;
  cost: string;
  archetype: string;
  overview: string;
  keyNuances: string[];
  agentVsHumanMatrix: AgentVsHumanMatrix;
  endpoints: OAuthEndpoints;
  scopes: ScopeItem[];
  setupSteps: SetupStep[];
  blockersAndSolutions: BlockerItem[];
  evidence: EvidenceInfo;
}

export interface InvestigationLog {
  stage: string;
  message: string;
}

