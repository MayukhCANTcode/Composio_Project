import React, { useState, useEffect } from 'react';
import { AppProfile } from './types';
import { Navbar } from './components/Navbar';
import { AppCard } from './components/AppCard';
import { AppDetail } from './components/AppDetail';
import { InvestigationTerminal } from './components/InvestigationTerminal';
import { ComparisonMatrix } from './components/ComparisonMatrix';
import { Search, Filter, ExternalLink, PlusCircle } from 'lucide-react';

export const App: React.FC = () => {
  const [apps, setApps] = useState<AppProfile[]>([]);
  const [selectedAppId, setSelectedAppId] = useState<string | null>(null);
  const [selectedApp, setSelectedApp] = useState<AppProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [difficultyFilter, setDifficultyFilter] = useState('all');
  const [approvalFilter, setApprovalFilter] = useState('all');
  const [isInvestigateOpen, setIsInvestigateOpen] = useState(false);
  const [isMatrixView, setIsMatrixView] = useState(false);

  // Sync with URL hash for shareability (e.g. #/app/slack)
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      if (hash.startsWith('#/app/')) {
        const id = hash.replace('#/app/', '');
        setSelectedAppId(id);
        setIsMatrixView(false);
      } else if (hash === '#/matrix') {
        setIsMatrixView(true);
        setSelectedAppId(null);
      } else {
        setSelectedAppId(null);
        setIsMatrixView(false);
      }
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Fetch all apps
  const fetchApps = async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/apps');
      const data = await res.json();
      setApps(data.apps || []);
    } catch (err) {
      console.error('Failed to fetch apps:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchApps();
  }, []);

  // Fetch detailed app profile when selectedAppId changes
  useEffect(() => {
    if (!selectedAppId) {
      setSelectedApp(null);
      return;
    }

    const fetchDetail = async () => {
      try {
        const res = await fetch(`/api/apps/${selectedAppId}`);
        if (res.ok) {
          const data = await res.json();
          setSelectedApp(data);
        } else {
          console.error('App not found:', selectedAppId);
        }
      } catch (err) {
        console.error('Failed to fetch app detail:', err);
      }
    };

    fetchDetail();
  }, [selectedAppId]);

  const handleSelectApp = (id: string | null) => {
    if (id) {
      window.location.hash = `#/app/${id}`;
    } else {
      window.location.hash = '';
    }
  };

  const handleViewMatrix = () => {
    window.location.hash = '#/matrix';
  };

  // Filter apps in grid
  const filteredApps = apps.filter((app) => {
    const matchesSearch =
      searchQuery === '' ||
      app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.archetype.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory =
      categoryFilter === 'all' ||
      app.category.toLowerCase().includes(categoryFilter.toLowerCase());

    const matchesDifficulty =
      difficultyFilter === 'all' ||
      app.difficulty.toString() === difficultyFilter;

    const matchesApproval =
      approvalFilter === 'all' ||
      (approvalFilter === 'required' ? app.approvalRequired : !app.approvalRequired);

    return matchesSearch && matchesCategory && matchesDifficulty && matchesApproval;
  });

  return (
    <div className="min-h-screen flex flex-col bg-zinc-950 text-zinc-100 font-sans selection:bg-zinc-800 selection:text-white">
      <Navbar
        totalApps={apps.length}
        onOpenInvestigate={() => setIsInvestigateOpen(true)}
        onSelectApp={handleSelectApp}
        onViewComparison={handleViewMatrix}
        isComparisonActive={isMatrixView}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* View 1: App Detail */}
        {selectedApp ? (
          <AppDetail app={selectedApp} onBack={() => handleSelectApp(null)} />
        ) : isMatrixView ? (
          /* View 2: Dev-to-Prod Friction Matrix */
          <ComparisonMatrix apps={apps} onSelectApp={handleSelectApp} />
        ) : (
          /* View 3: App Library & Universal Search */
          <div className="space-y-7">
            {/* Standard Hero Section */}
            <div className="rounded-2xl border border-zinc-800 bg-zinc-900/40 p-6 sm:p-9 shadow-sm">
              <div className="max-w-3xl space-y-3">
                <div className="inline-flex items-center space-x-2 text-xs font-mono text-zinc-400">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
                  <span>OAuth Integration & App Review Directory</span>
                </div>

                <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight leading-tight">
                  OAuth Setup & Provider Review Guidance
                </h1>

                <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed max-w-2xl">
                  Implementation steps, approval timelines, permission scopes, and platform requirements for integrating 3rd-party SaaS applications into developer tools and autonomous agents.
                </p>

                {/* Search Bar */}
                <div className="pt-3 flex flex-col sm:flex-row items-stretch gap-2.5 max-w-2xl">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      placeholder="Search providers (Google, Slack, GitHub...) or type a custom app..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && filteredApps.length === 0 && searchQuery.trim()) {
                          setIsInvestigateOpen(true);
                        }
                      }}
                      className="w-full pl-10 pr-4 py-2 rounded-lg bg-zinc-950 border border-zinc-700/80 focus:border-sky-500 focus:outline-none text-xs text-white placeholder-zinc-500 shadow-inner"
                    />
                  </div>

                  <button
                    onClick={() => setIsInvestigateOpen(true)}
                    className="px-4 py-2 rounded-lg font-medium text-xs bg-sky-600 hover:bg-sky-500 text-white flex items-center justify-center space-x-1.5 transition-colors shrink-0 shadow-sm"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>Inspect Custom App</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Filter Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-xl bg-zinc-900/40 border border-zinc-800 text-xs">
              <div className="flex flex-wrap items-center gap-2.5">
                <span className="text-zinc-500 font-medium flex items-center space-x-1 text-[11px]">
                  <Filter className="w-3 h-3" />
                  <span>Filters:</span>
                </span>

                {/* Difficulty */}
                <select
                  value={difficultyFilter}
                  onChange={(e) => setDifficultyFilter(e.target.value)}
                  className="px-2.5 py-1 rounded-md bg-zinc-950 border border-zinc-800 text-zinc-300 focus:outline-none focus:border-zinc-600 text-xs"
                >
                  <option value="all">All Difficulties</option>
                  <option value="1">Level 1 (Low / Instant)</option>
                  <option value="2">Level 2 (Low-Mid)</option>
                  <option value="3">Level 3 (Moderate)</option>
                  <option value="4">Level 4 (High Friction)</option>
                  <option value="5">Level 5 (Strict / CASA)</option>
                </select>

                {/* Approval Requirement */}
                <select
                  value={approvalFilter}
                  onChange={(e) => setApprovalFilter(e.target.value)}
                  className="px-2.5 py-1 rounded-md bg-zinc-950 border border-zinc-800 text-zinc-300 focus:outline-none focus:border-zinc-600 text-xs"
                >
                  <option value="all">All Review Policies</option>
                  <option value="instant">Instant Self-Serve</option>
                  <option value="required">Review Required</option>
                </select>

                {/* Categories */}
                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="px-2.5 py-1 rounded-md bg-zinc-950 border border-zinc-800 text-zinc-300 focus:outline-none focus:border-zinc-600 text-xs"
                >
                  <option value="all">All Categories</option>
                  <option value="Productivity">Productivity</option>
                  <option value="Developer Tools">Developer Tools</option>
                  <option value="Communication">Communication</option>
                  <option value="CRM">CRM & Enterprise</option>
                  <option value="Social">Social</option>
                  <option value="Finance">Finance</option>
                  <option value="E-commerce">E-commerce</option>
                </select>
              </div>

              <div className="text-zinc-500 font-mono text-[11px]">
                {filteredApps.length} of {apps.length} providers
              </div>
            </div>

            {/* App Grid */}
            {filteredApps.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredApps.map((app) => (
                  <AppCard
                    key={app.id}
                    app={app}
                    onSelect={(id) => handleSelectApp(id)}
                  />
                ))}
              </div>
            ) : (
              /* Custom inspection CTA */
              <div className="p-10 text-center rounded-xl border border-dashed border-zinc-800 bg-zinc-900/20 space-y-3 max-w-lg mx-auto">
                <div className="space-y-1">
                  <h3 className="text-sm font-semibold text-white">
                    "{searchQuery}" is not yet in the pre-indexed directory
                  </h3>
                  <p className="text-xs text-zinc-400">
                    Use the inspector to scan its public documentation, discover endpoints, and generate a structured guide.
                  </p>
                </div>
                <button
                  onClick={() => setIsInvestigateOpen(true)}
                  className="px-4 py-2 rounded-md font-medium text-xs bg-sky-600 hover:bg-sky-500 text-white inline-flex items-center space-x-1.5 transition-colors shadow-sm"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>Inspect "{searchQuery}"</span>
                </button>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800/80 bg-zinc-950 py-6 text-xs text-zinc-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <span className="font-semibold text-zinc-400">OAuthCompass</span>
            <span>—</span>
            <span>OAuth integration and provider review guidance for developers.</span>
          </div>
          <div className="flex items-center space-x-4">
            <a
              href="https://docs.composio.dev/toolkits/managed-auth"
              target="_blank"
              rel="noreferrer"
              className="text-zinc-400 hover:text-zinc-200 hover:underline flex items-center space-x-1"
            >
              <span>Managed Auth Reference</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      </footer>

      {/* Live Investigation Terminal Modal */}
      <InvestigationTerminal
        isOpen={isInvestigateOpen}
        onClose={() => setIsInvestigateOpen(false)}
        onAppInvestigated={(newApp) => {
          fetchApps();
          handleSelectApp(newApp.id);
        }}
      />
    </div>
  );
};

export default App;
