import React, { useState } from 'react';
import { Search, CheckCircle2, AlertCircle, Loader2, ArrowRight, X, FileText, Globe } from 'lucide-react';
import { AppProfile, InvestigationLog } from '../types';

interface InvestigationTerminalProps {
  isOpen: boolean;
  onClose: () => void;
  onAppInvestigated: (app: AppProfile) => void;
}

export const InvestigationTerminal: React.FC<InvestigationTerminalProps> = ({
  isOpen,
  onClose,
  onAppInvestigated
}) => {
  const [query, setQuery] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [logs, setLogs] = useState<InvestigationLog[]>([]);
  const [resultApp, setResultApp] = useState<AppProfile | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleStartInvestigation = async (overrideQuery?: string) => {
    const target = overrideQuery || query;
    if (!target.trim()) return;

    setIsRunning(true);
    setLogs([]);
    setResultApp(null);
    setError(null);

    try {
      const response = await fetch('/api/investigate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ query: target })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to inspect app');
      }

      setLogs(data.logs || []);
      setResultApp(data.app);
    } catch (err: any) {
      setError(err.message || 'Inspection failed');
    } finally {
      setIsRunning(false);
    }
  };

  const handleQuickPick = (name: string) => {
    setQuery(name);
    handleStartInvestigation(name);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-2xl bg-zinc-900 border border-zinc-800 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-zinc-800 flex items-center justify-between bg-zinc-950/60">
          <div className="flex items-center space-x-2.5">
            <div className="w-7 h-7 rounded-md bg-zinc-800 border border-zinc-700 flex items-center justify-center text-zinc-300">
              <Search className="w-3.5 h-3.5 text-sky-400" />
            </div>
            <div>
              <h3 className="font-semibold text-zinc-100 text-sm">
                OAuth Specification Inspector
              </h3>
              <p className="text-[11px] text-zinc-400">Discover endpoints, scopes, and approval requirements for any provider</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Input & Form */}
        <div className="p-5 border-b border-zinc-800 space-y-3 bg-zinc-900/60">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleStartInvestigation();
            }}
            className="flex items-center gap-2"
          >
            <div className="relative flex-1">
              <input
                type="text"
                placeholder="Enter app name (e.g. Airtable, Calendly, Dropbox) or website..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                disabled={isRunning}
                className="w-full pl-3 pr-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700/80 focus:border-sky-500 focus:outline-none text-xs text-white placeholder-zinc-500 disabled:opacity-50"
              />
            </div>
            <button
              type="submit"
              disabled={isRunning || !query.trim()}
              className="px-4 py-2 rounded-lg text-xs font-semibold bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white shadow-sm flex items-center space-x-1.5 transition-colors"
            >
              {isRunning ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Scanning...</span>
                </>
              ) : (
                <>
                  <Search className="w-3.5 h-3.5" />
                  <span>Inspect</span>
                </>
              )}
            </button>
          </form>

          {/* Quick Suggestions */}
          <div className="flex items-center space-x-2 text-xs text-zinc-400 pt-0.5">
            <span className="text-zinc-500 text-[11px]">Examples:</span>
            {['Airtable', 'Calendly', 'Dropbox', 'ClickUp', 'Asana'].map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => handleQuickPick(item)}
                disabled={isRunning}
                className="px-2 py-0.5 rounded text-[11px] bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-colors border border-zinc-700/60"
              >
                {item}
              </button>
            ))}
          </div>
        </div>

        {/* Inspection Steps Log */}
        <div className="p-5 overflow-y-auto flex-1 font-mono text-xs bg-zinc-950 space-y-2">
          {logs.length === 0 && !isRunning && !error && (
            <div className="text-zinc-500 py-8 text-center font-sans space-y-1.5">
              <Globe className="w-6 h-6 text-zinc-600 mx-auto" />
              <p className="text-xs">Enter an app or documentation link above to inspect its OAuth 2.0 configuration and review policies.</p>
            </div>
          )}

          {logs.map((log, index) => (
            <div key={index} className="flex items-start space-x-2.5 text-zinc-300">
              <span className="text-zinc-500 text-[10px] select-none font-bold">[{index + 1}]</span>
              <span className="text-zinc-500 font-mono text-[11px] w-44 shrink-0">
                {log.stage}
              </span>
              <span className="text-zinc-200 text-xs flex-1 font-sans">{log.message}</span>
            </div>
          ))}

          {isRunning && (
            <div className="flex items-center space-x-2 text-sky-400 pt-2 text-xs font-sans">
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              <span>Scanning documentation and testing endpoints...</span>
            </div>
          )}

          {error && (
            <div className="p-3 rounded-lg bg-red-950/40 border border-red-800/80 text-red-300 flex items-center space-x-2 text-xs font-sans mt-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {resultApp && (
            <div className="mt-4 p-4 rounded-lg bg-zinc-900 border border-zinc-700 font-sans space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span className="font-semibold text-zinc-100 text-xs">
                    Specification Generated for {resultApp.name}
                  </span>
                </div>
                <span className="text-[11px] px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 border border-zinc-700">
                  {resultApp.difficultyLabel}
                </span>
              </div>
              <p className="text-xs text-zinc-300 leading-relaxed">{resultApp.overview}</p>
              <div className="pt-2 flex justify-end">
                <button
                  onClick={() => {
                    onAppInvestigated(resultApp);
                    onClose();
                  }}
                  className="px-3.5 py-1.5 rounded-md text-xs font-medium bg-sky-600 hover:bg-sky-500 text-white flex items-center space-x-1.5 transition-colors"
                >
                  <span>Open Full Guide</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
