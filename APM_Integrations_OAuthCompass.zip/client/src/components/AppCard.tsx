import React from 'react';
import { AppProfile } from '../types';
import { Clock, ShieldAlert, CheckCircle2, ArrowRight } from 'lucide-react';

interface AppCardProps {
  app: Partial<AppProfile>;
  onSelect: (id: string) => void;
}

export const AppCard: React.FC<AppCardProps> = ({ app, onSelect }) => {
  const getDifficultyBadge = (level: number = 1) => {
    switch (level) {
      case 1:
        return { label: 'Level 1: Low', badge: 'bg-emerald-950/60 text-emerald-400 border-emerald-800/80' };
      case 2:
        return { label: 'Level 2: Low-Mid', badge: 'bg-teal-950/60 text-teal-400 border-teal-800/80' };
      case 3:
        return { label: 'Level 3: Moderate', badge: 'bg-amber-950/60 text-amber-400 border-amber-800/80' };
      case 4:
        return { label: 'Level 4: High', badge: 'bg-orange-950/60 text-orange-400 border-orange-800/80' };
      case 5:
        return { label: 'Level 5: Strict', badge: 'bg-rose-950/60 text-rose-400 border-rose-800/80' };
      default:
        return { label: `Level ${level}`, badge: 'bg-zinc-900 text-zinc-400 border-zinc-800' };
    }
  };

  const difficulty = getDifficultyBadge(app.difficulty);

  return (
    <div
      onClick={() => app.id && onSelect(app.id)}
      className="group relative rounded-xl border border-zinc-800/90 bg-zinc-900/40 p-5 hover:border-zinc-700 hover:bg-zinc-900/80 transition-all duration-150 cursor-pointer flex flex-col justify-between"
    >
      <div>
        {/* Top Badges */}
        <div className="flex items-center justify-between gap-2 mb-3">
          <span className={`text-[11px] px-2 py-0.5 rounded font-mono font-medium border ${difficulty.badge}`}>
            {difficulty.label}
          </span>
          <span className="text-[11px] text-zinc-400 font-medium px-2 py-0.5 rounded bg-zinc-800/60 border border-zinc-800">
            {app.category}
          </span>
        </div>

        {/* Title */}
        <div className="flex items-center justify-between">
          <h3 className="text-base font-semibold text-zinc-100 group-hover:text-sky-400 transition-colors">
            {app.name}
          </h3>
          <ArrowRight className="w-3.5 h-3.5 text-zinc-500 group-hover:text-sky-400 group-hover:translate-x-0.5 transition-all" />
        </div>

        {/* Archetype */}
        <div className="mt-1 text-xs text-zinc-400 font-normal">
          {app.archetype}
        </div>

        {/* Overview snippet */}
        <p className="mt-2 text-xs text-zinc-400 line-clamp-2 leading-relaxed font-normal">
          {app.overview}
        </p>
      </div>

      {/* Metrics Footer */}
      <div className="mt-4 pt-3 border-t border-zinc-800/80 flex items-center justify-between text-xs">
        <div className="flex items-center space-x-1.5 text-zinc-400">
          <Clock className="w-3.5 h-3.5 text-zinc-500" />
          <span className="text-zinc-300 font-medium text-[11px]">{app.timeToProductionApproval}</span>
        </div>

        <div>
          {app.approvalRequired ? (
            <span className="inline-flex items-center space-x-1 text-amber-400 text-[11px] font-medium bg-amber-950/40 px-2 py-0.5 rounded border border-amber-900/60">
              <ShieldAlert className="w-3 h-3 text-amber-400" />
              <span>Review Required</span>
            </span>
          ) : (
            <span className="inline-flex items-center space-x-1 text-emerald-400 text-[11px] font-medium bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-900/60">
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              <span>Instant Setup</span>
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
