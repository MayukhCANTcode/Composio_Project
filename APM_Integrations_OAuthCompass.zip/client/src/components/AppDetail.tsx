import React, { useState, useEffect } from 'react';
import { AppProfile, ScopeItem } from '../types';
import { 
  ArrowLeft, Clock, ShieldAlert, CheckCircle2, AlertTriangle, ExternalLink, 
  Copy, Check, FileDown, Bot, User, CheckSquare, Square, 
  HelpCircle, Code2, Link as LinkIcon, RefreshCw, KeyRound, Lock, Info, Layers, Check as CheckIcon
} from 'lucide-react';

interface AppDetailProps {
  app: AppProfile;
  onBack: () => void;
}

export const AppDetail: React.FC<AppDetailProps> = ({ app, onBack }) => {
  const [activeTab, setActiveTab] = useState<'checklist' | 'agent-human' | 'scopes' | 'simulator' | 'blockers' | 'evidence'>('checklist');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  
  // Checklist task progress in local state (keyed by appId + stepId)
  const [stepStatus, setStepStatus] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem(`oauth_progress_${app.id}`);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Scope optimizer state
  const [selectedCaps, setSelectedCaps] = useState<string[]>(['identity']);
  const [optimizedResult, setOptimizedResult] = useState<any>(null);
  const [isOptimizing, setIsOptimizing] = useState(false);

  // URL Simulator state
  const [simClientId, setSimClientId] = useState('YOUR_CLIENT_ID');
  const [simRedirectUri, setSimRedirectUri] = useState('http://localhost:3000/api/auth/callback/' + app.id);
  const [simResult, setSimResult] = useState<any>(null);
  const [isSimulating, setIsSimulating] = useState(false);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    triggerScopeOptimization(['identity']);
    triggerUrlSimulation();
  }, [app.id]);

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const toggleStep = (stepId: string) => {
    const updated = { ...stepStatus, [stepId]: !stepStatus[stepId] };
    setStepStatus(updated);
    try {
      localStorage.setItem(`oauth_progress_${app.id}`, JSON.stringify(updated));
    } catch (err) {
      console.error('Failed to save progress:', err);
    }
  };

  const completedCount = app.setupSteps.filter(s => stepStatus[s.id]).length;
  const progressPercent = Math.round((completedCount / (app.setupSteps.length || 1)) * 100);

  const triggerScopeOptimization = async (caps: string[]) => {
    setIsOptimizing(true);
    try {
      const res = await fetch('/api/tools/scope-optimizer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ appId: app.id, capabilities: caps })
      });
      const data = await res.json();
      setOptimizedResult(data);
    } catch (err) {
      console.error('Scope optimizer error:', err);
    } finally {
      setIsOptimizing(false);
    }
  };

  const toggleCapability = (capId: string) => {
    const next = selectedCaps.includes(capId)
      ? selectedCaps.filter(c => c !== capId)
      : [...selectedCaps, capId];
    setSelectedCaps(next);
    triggerScopeOptimization(next);
  };

  const triggerUrlSimulation = async () => {
    setIsSimulating(true);
    try {
      const res = await fetch('/api/tools/build-auth-url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          providerId: app.id,
          authorizationEndpoint: app.endpoints.authorizationUrl,
          clientId: simClientId,
          redirectUri: simRedirectUri,
          scopes: app.scopes.slice(0, 2).map(s => s.name)
        })
      });
      const data = await res.json();
      setSimResult(data);
    } catch (err) {
      console.error('Auth simulator error:', err);
    } finally {
      setIsSimulating(false);
    }
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-150">
      {/* Top Breadcrumb & Share Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <button
          onClick={onBack}
          className="inline-flex items-center space-x-1.5 text-xs font-medium text-zinc-400 hover:text-white px-2.5 py-1.5 rounded-md bg-zinc-900 border border-zinc-800 transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Catalog</span>
        </button>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => handleCopy(window.location.href, 'share-url')}
            className="inline-flex items-center space-x-1.5 text-xs font-medium text-zinc-300 hover:text-white px-2.5 py-1.5 rounded-md bg-zinc-900 border border-zinc-800 hover:border-zinc-700 transition-colors"
          >
            {copiedKey === 'share-url' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <LinkIcon className="w-3.5 h-3.5 text-zinc-400" />}
            <span>{copiedKey === 'share-url' ? 'Copied' : 'Share Guide'}</span>
          </button>

          <a
            href={`/api/export/${app.id}`}
            download={`${app.id}-oauth-guide.md`}
            className="inline-flex items-center space-x-1.5 text-xs font-medium text-zinc-300 hover:text-white px-2.5 py-1.5 rounded-md bg-zinc-900 border border-zinc-800 hover:border-zinc-700 transition-colors"
          >
            <FileDown className="w-3.5 h-3.5 text-zinc-400" />
            <span>Export Markdown</span>
          </a>
        </div>
      </div>

      {/* Hero Header */}
      <div className="p-6 sm:p-7 rounded-xl border border-zinc-800 bg-zinc-900/40">
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs px-2 py-0.5 rounded font-mono font-medium bg-zinc-800 text-zinc-300 border border-zinc-700/80">
              {app.category}
            </span>
            <span className="text-xs px-2 py-0.5 rounded font-mono text-zinc-400 bg-zinc-900 border border-zinc-800">
              {app.authType}
            </span>
            <span className="text-xs px-2 py-0.5 rounded text-zinc-400 bg-zinc-900 border border-zinc-800">
              {app.archetype}
            </span>
          </div>

          <h1 className="text-2xl font-bold text-white tracking-tight">
            {app.name}
          </h1>

          <p className="text-xs sm:text-sm text-zinc-300 max-w-3xl leading-relaxed">
            {app.overview}
          </p>

          <div className="pt-1 flex flex-wrap items-center gap-4 text-xs">
            <a
              href={app.developerPortal}
              target="_blank"
              rel="noreferrer"
              className="text-sky-400 hover:underline inline-flex items-center space-x-1"
            >
              <span>Developer Portal</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <span className="text-zinc-600">•</span>
            <a
              href={app.evidence.officialDocsUrl}
              target="_blank"
              rel="noreferrer"
              className="text-zinc-400 hover:underline inline-flex items-center space-x-1"
            >
              <span>OAuth Specifications</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>

        {/* 4 Key Metrics Bar */}
        <div className="mt-6 pt-5 border-t border-zinc-800/80 grid grid-cols-2 lg:grid-cols-4 gap-3.5">
          {/* Difficulty */}
          <div className="p-3.5 rounded-lg bg-zinc-950/70 border border-zinc-800/80 space-y-1">
            <span className="text-[11px] text-zinc-400 block font-medium">Difficulty Level</span>
            <div className="flex items-center space-x-2">
              <span className={`text-lg font-bold ${app.difficulty <= 2 ? 'text-emerald-400' : (app.difficulty === 3 ? 'text-amber-400' : 'text-rose-400')}`}>
                Level {app.difficulty}/5
              </span>
              <span className="text-xs text-zinc-400 truncate">
                {app.difficultyLabel.split('(')[0]}
              </span>
            </div>
          </div>

          {/* Time to Dev vs Prod */}
          <div className="p-3.5 rounded-lg bg-zinc-950/70 border border-zinc-800/80 space-y-1">
            <span className="text-[11px] text-zinc-400 block font-medium">Approval Wait Time</span>
            <div className="flex items-center space-x-1.5">
              <Clock className="w-3.5 h-3.5 text-zinc-500" />
              <span className="text-xs font-semibold text-zinc-200 truncate">
                {app.timeToProductionApproval}
              </span>
            </div>
          </div>

          {/* Approval Requirement */}
          <div className="p-3.5 rounded-lg bg-zinc-950/70 border border-zinc-800/80 space-y-1">
            <span className="text-[11px] text-zinc-400 block font-medium">Review Policy</span>
            <div className="flex items-center space-x-1.5">
              {app.approvalRequired ? (
                <>
                  <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                  <span className="text-xs font-medium text-amber-300">Review Required</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-xs font-medium text-emerald-300">Instant Self-Serve</span>
                </>
              )}
            </div>
          </div>

          {/* Cost */}
          <div className="p-3.5 rounded-lg bg-zinc-950/70 border border-zinc-800/80 space-y-1">
            <span className="text-[11px] text-zinc-400 block font-medium">Estimated Platform Cost</span>
            <div className="text-xs font-medium text-zinc-300 truncate" title={app.cost}>
              {app.cost}
            </div>
          </div>
        </div>
      </div>

      {/* Critical Platform Traps Callout */}
      <div className="p-4 rounded-xl bg-zinc-900 border border-amber-900/40 text-zinc-300 space-y-2">
        <div className="flex items-center space-x-2 text-amber-400 font-semibold text-xs">
          <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
          <span>Known Platform Traps & Nuances</span>
        </div>
        <ul className="space-y-1.5 text-xs text-zinc-300 pl-6 list-disc">
          {app.keyNuances.map((nuance, index) => (
            <li key={index} className="leading-relaxed">
              {nuance}
            </li>
          ))}
        </ul>
      </div>

      {/* Tab Navigation */}
      <div className="border-b border-zinc-800 flex items-center space-x-1 overflow-x-auto text-xs font-medium">
        <button
          onClick={() => setActiveTab('checklist')}
          className={`px-3 py-2 border-b-2 transition-colors flex items-center space-x-1.5 whitespace-nowrap ${
            activeTab === 'checklist'
              ? 'border-sky-500 text-white font-semibold'
              : 'border-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <CheckSquare className="w-3.5 h-3.5" />
          <span>Setup Steps ({completedCount}/{app.setupSteps.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('agent-human')}
          className={`px-3 py-2 border-b-2 transition-colors flex items-center space-x-1.5 whitespace-nowrap ${
            activeTab === 'agent-human'
              ? 'border-sky-500 text-white font-semibold'
              : 'border-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Bot className="w-3.5 h-3.5 text-zinc-400" />
          <span>Automation vs. Developer Action</span>
        </button>

        <button
          onClick={() => setActiveTab('scopes')}
          className={`px-3 py-2 border-b-2 transition-colors flex items-center space-x-1.5 whitespace-nowrap ${
            activeTab === 'scopes'
              ? 'border-sky-500 text-white font-semibold'
              : 'border-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Code2 className="w-3.5 h-3.5 text-zinc-400" />
          <span>Scope Calculator & Justifications</span>
        </button>

        <button
          onClick={() => setActiveTab('simulator')}
          className={`px-3 py-2 border-b-2 transition-colors flex items-center space-x-1.5 whitespace-nowrap ${
            activeTab === 'simulator'
              ? 'border-sky-500 text-white font-semibold'
              : 'border-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <KeyRound className="w-3.5 h-3.5 text-zinc-400" />
          <span>URL Builder & PKCE</span>
        </button>

        <button
          onClick={() => setActiveTab('blockers')}
          className={`px-3 py-2 border-b-2 transition-colors flex items-center space-x-1.5 whitespace-nowrap ${
            activeTab === 'blockers'
              ? 'border-sky-500 text-white font-semibold'
              : 'border-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <HelpCircle className="w-3.5 h-3.5 text-zinc-400" />
          <span>Troubleshooting ({app.blockersAndSolutions.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('evidence')}
          className={`px-3 py-2 border-b-2 transition-colors flex items-center space-x-1.5 whitespace-nowrap ${
            activeTab === 'evidence'
              ? 'border-sky-500 text-white font-semibold'
              : 'border-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Info className="w-3.5 h-3.5 text-zinc-400" />
          <span>Evidence & Grounding</span>
        </button>
      </div>

      {/* Tab 1: Checklist */}
      {activeTab === 'checklist' && (
        <div className="space-y-4">
          <div className="p-3.5 rounded-lg bg-zinc-900 border border-zinc-800 flex items-center justify-between text-xs">
            <span className="text-zinc-300 font-medium">Checklist Progress: {completedCount} of {app.setupSteps.length} items completed</span>
            <span className="font-mono text-zinc-400 font-semibold">{progressPercent}%</span>
          </div>

          <div className="space-y-3">
            {app.setupSteps.map((step) => {
              const isChecked = !!stepStatus[step.id];
              return (
                <div
                  key={step.id}
                  className={`p-4 rounded-xl border transition-colors ${
                    isChecked
                      ? 'bg-zinc-950/40 border-zinc-800/60 opacity-75'
                      : 'bg-zinc-900/50 border-zinc-800 hover:border-zinc-700'
                  }`}
                >
                  <div className="flex items-start space-x-3">
                    <button
                      onClick={() => toggleStep(step.id)}
                      className="mt-0.5 text-zinc-400 hover:text-zinc-200 transition-colors"
                    >
                      {isChecked ? (
                        <CheckSquare className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Square className="w-4 h-4 text-zinc-500" />
                      )}
                    </button>

                    <div className="space-y-1.5 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-[11px] font-mono text-zinc-500">
                          Step {step.stepNumber}
                        </span>
                        <h4 className={`text-sm font-semibold ${isChecked ? 'line-through text-zinc-400' : 'text-zinc-100'}`}>
                          {step.title}
                        </h4>
                        <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400 border border-zinc-700">
                          {step.agentSupport}
                        </span>
                        <span className="text-[11px] text-zinc-500">
                          ~{step.estimatedMinutes}m
                        </span>
                      </div>

                      <p className="text-xs text-zinc-300 leading-relaxed font-normal">
                        {step.description}
                      </p>

                      {step.copyableSnippet && (
                        <div className="mt-2 relative rounded-lg bg-zinc-950 border border-zinc-800 p-3 font-mono text-xs text-zinc-200 overflow-x-auto">
                          <pre>{step.copyableSnippet}</pre>
                          <button
                            onClick={() => handleCopy(step.copyableSnippet!, `step-${step.id}`)}
                            className="absolute top-2 right-2 p-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors"
                            title="Copy snippet"
                          >
                            {copiedKey === `step-${step.id}` ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      )}

                      {step.docsUrl && (
                        <div className="pt-0.5">
                          <a
                            href={step.docsUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="text-xs text-sky-400 hover:underline inline-flex items-center space-x-1"
                          >
                            <span>Provider Step Documentation</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 2: Automation vs Developer Action Matrix */}
      {activeTab === 'agent-human' && (
        <div className="space-y-4">
          <div className="p-3.5 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 leading-relaxed">
            <p>
              Standard division of responsibilities: Automated routines (AI agent, SDK, or CI script) handle cryptographic flows and token exchanges. Platform governance mandates that developers directly perform legal entity verification, domain ownership records, and video recordings.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Automated Column */}
            <div className="p-5 rounded-xl bg-zinc-900/60 border border-zinc-800 space-y-3">
              <div className="flex items-center space-x-2.5 pb-2.5 border-b border-zinc-800">
                <Bot className="w-4 h-4 text-sky-400" />
                <h3 className="font-semibold text-zinc-100 text-sm">Automated via Agent / SDK</h3>
              </div>
              <ul className="space-y-2 text-xs text-zinc-300">
                {app.agentVsHumanMatrix.agentCapabilities.map((cap, i) => (
                  <li key={i} className="flex items-start space-x-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span className="leading-relaxed">{cap}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Developer Required Column */}
            <div className="p-5 rounded-xl bg-zinc-900/60 border border-zinc-800 space-y-3">
              <div className="flex items-center space-x-2.5 pb-2.5 border-b border-zinc-800">
                <User className="w-4 h-4 text-amber-400" />
                <h3 className="font-semibold text-zinc-100 text-sm">Required Developer Actions</h3>
              </div>
              <ul className="space-y-2 text-xs text-zinc-300">
                {app.agentVsHumanMatrix.humanRequirements.map((req, i) => (
                  <li key={i} className="flex items-start space-x-2">
                    <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                    <span className="leading-relaxed">{req}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Scope Calculator & Justifications */}
      {activeTab === 'scopes' && (
        <div className="space-y-5">
          <div className="p-5 rounded-xl bg-zinc-900/60 border border-zinc-800 space-y-3">
            <div>
              <h3 className="text-sm font-semibold text-zinc-100">Scope Calculator & Justification Generator</h3>
              <p className="text-xs text-zinc-400 mt-0.5">
                Select your integration requirements to determine the minimum required scopes and generate review-compliant justifications.
              </p>
            </div>

            {/* Capability Toggles */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
              {[
                { id: 'identity', label: 'User Identity (Email/Profile)' },
                { id: 'calendar', label: 'Calendar Scheduling' },
                { id: 'documents_read', label: 'Read Documents' },
                { id: 'documents_write', label: 'Export Documents' },
                { id: 'messages_write', label: 'Send Notifications' },
                { id: 'messages_read', label: 'Read Message Context' },
                { id: 'email_read', label: 'Read User Emails (Restricted)' },
                { id: 'social_publish', label: 'Publish Social Media Posts' },
              ].map((cap) => {
                const active = selectedCaps.includes(cap.id);
                return (
                  <button
                    key={cap.id}
                    onClick={() => toggleCapability(cap.id)}
                    className={`p-2.5 rounded-lg text-xs font-medium text-left border transition-colors ${
                      active
                        ? 'bg-zinc-800 border-sky-500 text-white'
                        : 'bg-zinc-950/60 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-0.5">
                      <span className="font-semibold text-xs">{cap.label.split('(')[0]}</span>
                      {active ? <CheckSquare className="w-3 h-3 text-sky-400" /> : <Square className="w-3 h-3 text-zinc-600" />}
                    </div>
                    <span className="text-[10px] text-zinc-500 block truncate">{cap.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Generated Result */}
          {optimizedResult && (
            <div className="p-5 rounded-xl bg-zinc-900/60 border border-zinc-800 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-zinc-800 text-xs">
                <div className="flex items-center space-x-2">
                  <span className="text-zinc-400">Risk Assessment:</span>
                  <span className="font-semibold text-zinc-200">
                    {optimizedResult.riskLevel}
                  </span>
                </div>

                {optimizedResult.requiresPaidAudit && (
                  <span className="text-xs text-red-400 font-semibold bg-red-950/50 px-2 py-0.5 rounded border border-red-900/60">
                    Third-Party Security Audit Required: {optimizedResult.auditEstimate}
                  </span>
                )}
              </div>

              <div>
                <span className="text-xs text-zinc-400 block mb-1">Generated Scope String:</span>
                <div className="p-2.5 rounded-lg bg-zinc-950 border border-zinc-800 font-mono text-xs text-zinc-200 flex items-center justify-between">
                  <span className="truncate">{optimizedResult.recommendedScopes.join(' ')}</span>
                  <button
                    onClick={() => handleCopy(optimizedResult.recommendedScopes.join(' '), 'scopes-str')}
                    className="p-1 rounded bg-zinc-800 text-zinc-400 hover:text-white"
                  >
                    {copiedKey === 'scopes-str' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-zinc-400">Platform Review Justification Form:</span>
                  <button
                    onClick={() => handleCopy(optimizedResult.justificationText, 'justification')}
                    className="text-xs text-sky-400 hover:underline inline-flex items-center space-x-1"
                  >
                    {copiedKey === 'justification' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedKey === 'justification' ? 'Copied' : 'Copy Text'}</span>
                  </button>
                </div>
                <div className="p-3.5 rounded-lg bg-zinc-950 border border-zinc-800 font-mono text-xs text-zinc-300 leading-relaxed whitespace-pre-wrap max-h-52 overflow-y-auto">
                  {optimizedResult.justificationText}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 4: URL Simulator & PKCE */}
      {activeTab === 'simulator' && (
        <div className="space-y-4">
          <div className="p-5 rounded-xl bg-zinc-900/60 border border-zinc-800 space-y-3">
            <h3 className="text-sm font-semibold text-zinc-100">Live URL Constructor & PKCE Parameters</h3>
            <p className="text-xs text-zinc-400">
              Validates callback format against RFC 6749 and computes standard RFC 7636 S256 code verifier and challenge.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
              <div className="space-y-1">
                <label className="text-xs text-zinc-400">Client ID</label>
                <input
                  type="text"
                  value={simClientId}
                  onChange={(e) => setSimClientId(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-md bg-zinc-950 border border-zinc-800 text-xs text-white focus:outline-none focus:border-zinc-600 font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs text-zinc-400">Redirect URI</label>
                <input
                  type="text"
                  value={simRedirectUri}
                  onChange={(e) => setSimRedirectUri(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-md bg-zinc-950 border border-zinc-800 text-xs text-white focus:outline-none focus:border-zinc-600 font-mono"
                />
              </div>
            </div>

            <div className="flex justify-end pt-1">
              <button
                onClick={triggerUrlSimulation}
                className="px-3 py-1.5 rounded-md text-xs font-medium bg-zinc-800 hover:bg-zinc-700 text-zinc-200 flex items-center space-x-1.5 transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Recalculate PKCE</span>
              </button>
            </div>
          </div>

          {simResult && (
            <div className="p-5 rounded-xl bg-zinc-900/60 border border-zinc-800 space-y-3 font-mono text-xs">
              <div className="space-y-1 font-sans">
                <span className="text-xs text-zinc-400">Redirect URI Pre-Flight Status:</span>
                {simResult.redirectValidation.valid ? (
                  <div className="p-2.5 rounded bg-zinc-950 border border-emerald-900/50 text-emerald-400 text-xs flex items-center space-x-2">
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                    <span>Valid RFC 6749 URI syntax and scheme accepted.</span>
                  </div>
                ) : (
                  <div className="p-2.5 rounded bg-zinc-950 border border-red-900/50 text-red-400 text-xs">
                    {simResult.redirectValidation.issues.join(', ')}
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                <div className="p-2.5 rounded bg-zinc-950 border border-zinc-800 space-y-0.5">
                  <span className="text-zinc-500 text-[10px] uppercase">code_verifier</span>
                  <div className="text-zinc-300 truncate">{simResult.pkce.codeVerifier}</div>
                </div>

                <div className="p-2.5 rounded bg-zinc-950 border border-zinc-800 space-y-0.5">
                  <span className="text-zinc-500 text-[10px] uppercase">code_challenge (S256)</span>
                  <div className="text-zinc-300 truncate">{simResult.pkce.codeChallenge}</div>
                </div>
              </div>

              <div className="space-y-1 pt-1 font-sans">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-zinc-400">Constructed Authorization URL:</span>
                  <button
                    onClick={() => handleCopy(simResult.authUrl, 'auth-url')}
                    className="text-xs text-sky-400 hover:underline inline-flex items-center space-x-1"
                  >
                    {copiedKey === 'auth-url' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedKey === 'auth-url' ? 'Copied' : 'Copy URL'}</span>
                  </button>
                </div>
                <div className="p-2.5 rounded bg-zinc-950 border border-zinc-800 font-mono text-xs text-zinc-300 break-all">
                  {simResult.authUrl}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 5: Troubleshooting */}
      {activeTab === 'blockers' && (
        <div className="space-y-3">
          {app.blockersAndSolutions.map((b, i) => (
            <div key={i} className="p-4 rounded-xl bg-zinc-900/50 border border-zinc-800 space-y-2 text-xs">
              <div className="font-mono font-semibold text-rose-400 flex items-center space-x-2">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{b.error}</span>
              </div>
              <div className="text-zinc-400 pl-5">
                <span className="text-zinc-300 font-medium">Cause: </span>
                {b.cause}
              </div>
              <div className="p-2.5 rounded bg-zinc-950 border border-zinc-800/80 text-zinc-200 pl-4 ml-5">
                <span className="text-emerald-400 font-semibold">Resolution: </span>
                {b.solution}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 6: Evidence & Grounding */}
      {activeTab === 'evidence' && (
        <div className="p-5 rounded-xl bg-zinc-900/50 border border-zinc-800 space-y-4 text-xs">
          <h3 className="text-sm font-semibold text-zinc-100">Audit Grounding & Verification</h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3 rounded bg-zinc-950 border border-zinc-800 space-y-0.5">
              <span className="text-[10px] text-zinc-500 uppercase font-mono">Verification Method</span>
              <span className="text-zinc-200 block font-medium">{app.evidence.verifiedVia}</span>
            </div>

            <div className="p-3 rounded bg-zinc-950 border border-zinc-800 space-y-0.5">
              <span className="text-[10px] text-zinc-500 uppercase font-mono">Confidence</span>
              <span className="text-zinc-200 block font-medium">{app.evidence.confidence}</span>
            </div>

            <div className="p-3 rounded bg-zinc-950 border border-zinc-800 space-y-0.5">
              <span className="text-[10px] text-zinc-500 uppercase font-mono">Last Audited</span>
              <span className="text-zinc-200 block font-medium">{app.evidence.lastVerifiedDate}</span>
            </div>
          </div>

          <div className="p-3 rounded bg-zinc-950 border border-zinc-800 space-y-1">
            <span className="text-zinc-400 font-medium">Audit Notes:</span>
            <p className="text-zinc-400 leading-relaxed font-normal">
              {app.evidence.notes}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
