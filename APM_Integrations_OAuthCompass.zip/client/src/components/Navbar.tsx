import React from 'react';
import { Compass, BookOpen, ShieldCheck, Search, PlusCircle } from 'lucide-react';

interface NavbarProps {
  totalApps: number;
  onOpenInvestigate: () => void;
  onSelectApp: (id: string | null) => void;
  onViewComparison: () => void;
  isComparisonActive: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  totalApps,
  onOpenInvestigate,
  onSelectApp,
  onViewComparison,
  isComparisonActive
}) => {
  return (
    <header className="sticky top-0 z-40 border-b border-zinc-800 bg-zinc-950/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between">
        {/* Brand */}
        <div 
          className="flex items-center space-x-3 cursor-pointer group"
          onClick={() => onSelectApp(null)}
        >
          <div className="w-8 h-8 rounded-lg bg-zinc-900 border border-zinc-700/80 flex items-center justify-center text-zinc-100 group-hover:border-zinc-500 transition-colors">
            <Compass className="w-4 h-4 text-sky-400" />
          </div>
          <div className="flex items-center space-x-2">
            <span className="font-semibold text-sm text-zinc-100 tracking-tight">OAuthCompass</span>
            <span className="text-[11px] px-2 py-0.5 rounded font-mono font-medium bg-zinc-900 border border-zinc-800 text-zinc-400">
              v1.0
            </span>
          </div>
        </div>

        {/* Center / Right controls */}
        <div className="flex items-center space-x-2.5">
          <button
            onClick={() => onSelectApp(null)}
            className="px-3 py-1.5 rounded-md text-xs font-medium text-zinc-300 hover:text-white hover:bg-zinc-900 border border-transparent hover:border-zinc-800 transition-colors flex items-center space-x-1.5"
          >
            <BookOpen className="w-3.5 h-3.5 text-zinc-400" />
            <span>Catalog ({totalApps})</span>
          </button>

          <button
            onClick={onViewComparison}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors flex items-center space-x-1.5 ${
              isComparisonActive
                ? 'bg-zinc-900 text-white border border-zinc-700'
                : 'text-zinc-300 hover:text-white hover:bg-zinc-900 border border-transparent hover:border-zinc-800'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-zinc-400" />
            <span>Comparison Matrix</span>
          </button>

          <div className="h-4 w-px bg-zinc-800 mx-1" />

          <button
            onClick={onOpenInvestigate}
            className="px-3 py-1.5 rounded-md text-xs font-medium bg-sky-600 hover:bg-sky-500 text-white transition-colors flex items-center space-x-1.5 shadow-sm"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>Inspect Custom App</span>
          </button>
        </div>
      </div>
    </header>
  );
};
