import React from 'react';
import { AppProfile } from '../types';
import { ShieldAlert, CheckCircle2, ArrowRight, Clock } from 'lucide-react';

interface ComparisonMatrixProps {
  apps: AppProfile[];
  onSelectApp: (id: string) => void;
}

export const ComparisonMatrix: React.FC<ComparisonMatrixProps> = ({ apps, onSelectApp }) => {
  return (
    <div className="space-y-5 animate-in fade-in duration-150">
      <div>
        <h2 className="text-xl font-bold text-white tracking-tight">
          Provider Setup & Approval Comparison
        </h2>
        <p className="text-xs text-zinc-400 mt-1">
          Compare implementation friction, verification requirements, and platform wait times across third-party OAuth providers.
        </p>
      </div>

      <div className="rounded-xl border border-zinc-800 bg-zinc-900/40 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-zinc-300">
            <thead className="bg-zinc-950/80 text-[11px] font-mono text-zinc-400 border-b border-zinc-800">
              <tr>
                <th className="py-3 px-4 font-semibold">Provider</th>
                <th className="py-3 px-3 font-semibold">Archetype</th>
                <th className="py-3 px-3 font-semibold">Difficulty</th>
                <th className="py-3 px-3 font-semibold">Approval Wait</th>
                <th className="py-3 px-3 font-semibold">Review Required</th>
                <th className="py-3 px-3 font-semibold">Cost / Audit</th>
                <th className="py-3 px-3 text-right font-semibold">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60 font-sans">
              {apps.map((app) => (
                <tr
                  key={app.id}
                  onClick={() => onSelectApp(app.id)}
                  className="hover:bg-zinc-800/40 transition-colors cursor-pointer group"
                >
                  {/* Provider Name */}
                  <td className="py-3 px-4 font-medium text-zinc-100 group-hover:text-sky-400 transition-colors">
                    <div>{app.name}</div>
                    <div className="text-[10px] text-zinc-500 font-mono">
                      {app.category}
                    </div>
                  </td>

                  {/* Archetype */}
                  <td className="py-3 px-3 text-zinc-400 text-xs">
                    {app.archetype}
                  </td>

                  {/* Difficulty */}
                  <td className="py-3 px-3 whitespace-nowrap">
                    <span className={`px-2 py-0.5 rounded text-[11px] font-mono font-medium ${
                      app.difficulty <= 2
                        ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/80'
                        : (app.difficulty === 3
                          ? 'bg-amber-950/60 text-amber-400 border border-amber-800/80'
                          : 'bg-rose-950/60 text-rose-400 border border-rose-800/80')
                    }`}>
                      Level {app.difficulty}/5
                    </span>
                  </td>

                  {/* Approval Wait */}
                  <td className="py-3 px-3 whitespace-nowrap text-zinc-300">
                    <div className="flex items-center space-x-1.5">
                      <Clock className="w-3 h-3 text-zinc-500" />
                      <span>{app.timeToProductionApproval}</span>
                    </div>
                  </td>

                  {/* Approval Required */}
                  <td className="py-3 px-3 whitespace-nowrap">
                    {app.approvalRequired ? (
                      <span className="inline-flex items-center space-x-1 text-amber-400 text-[11px] font-medium bg-amber-950/40 px-2 py-0.5 rounded border border-amber-900/60">
                        <ShieldAlert className="w-3 h-3" />
                        <span>Required</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center space-x-1 text-emerald-400 text-[11px] font-medium bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-900/60">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>Instant</span>
                      </span>
                    )}
                  </td>

                  {/* Cost */}
                  <td className="py-3 px-3 text-xs font-mono text-zinc-400 max-w-xs truncate" title={app.cost}>
                    {app.cost}
                  </td>

                  {/* Action */}
                  <td className="py-3 px-3 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectApp(app.id);
                      }}
                      className="inline-flex items-center space-x-1 text-xs font-medium text-sky-400 hover:text-sky-300 transition-colors"
                    >
                      <span>Guide</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
