import crypto from 'crypto';

/**
 * RFC 7636 PKCE Generator
 */
export function generatePkce() {
  // Generate a random 43 to 128 character verifier
  const verifier = crypto.randomBytes(32).toString('base64url');
  // Compute SHA-256 hash of verifier
  const challenge = crypto.createHash('sha256').update(verifier).digest('base64url');
  return {
    codeVerifier: verifier,
    codeChallenge: challenge,
    codeChallengeMethod: 'S256'
  };
}

/**
 * Generate CSRF State Token
 */
export function generateState() {
  return crypto.randomBytes(16).toString('hex');
}

/**
 * Validate Redirect URI against RFC 6749 and Provider Constraints
 */
export function validateRedirectUri(providerId, uri) {
  const issues = [];
  const warnings = [];

  if (!uri || typeof uri !== 'string') {
    return { valid: false, issues: ['Redirect URI is required.'] };
  }

  try {
    const parsed = new URL(uri);
    
    // Check protocol
    const isLocalhost = parsed.hostname === 'localhost' || parsed.hostname === '127.0.0.1';
    if (parsed.protocol !== 'https:' && !isLocalhost) {
      issues.push('Production redirect URIs must use HTTPS. Insecure HTTP is only permitted on localhost.');
    }

    // Check for fragment identifier (RFC 6749 Section 3.1.2 explicitly forbids fragments)
    if (parsed.hash) {
      issues.push('Redirect URI must not contain a URL fragment identifier (#).');
    }

    // Check wildcards
    if (uri.includes('*')) {
      issues.push('Wildcard domains/paths are strictly forbidden by major OAuth providers (RFC 6749 Section 3.1.2).');
    }

    // Provider specific checks
    if (providerId === 'spotify' && uri.endsWith('/')) {
      warnings.push('Spotify is strict on trailing slashes. Ensure your developer dashboard configuration matches exactly.');
    }
    if (providerId === 'google-workspace' && !isLocalhost) {
      warnings.push('Google requires this domain to be verified in Google Search Console under your GCP project account.');
    }
    if (providerId === 'salesforce' && isLocalhost) {
      warnings.push('Salesforce Connected Apps require localhost callbacks to use exact matching port.');
    }
  } catch (err) {
    issues.push(`Invalid URI format: ${err.message}`);
  }

  return {
    valid: issues.length === 0,
    issues,
    warnings
  };
}

/**
 * Construct full RFC 6749 Authorization URL
 */
export function buildAuthUrl({
  authorizationEndpoint,
  clientId,
  redirectUri,
  scopes = [],
  state,
  codeChallenge,
  codeChallengeMethod = 'S256',
  prompt,
  accessType,
  providerId
}) {
  if (!authorizationEndpoint || !clientId || !redirectUri) {
    throw new Error('authorizationEndpoint, clientId, and redirectUri are required.');
  }

  const url = new URL(authorizationEndpoint);
  url.searchParams.set('response_type', 'code');
  url.searchParams.set('client_id', clientId);
  url.searchParams.set('redirect_uri', redirectUri);

  if (scopes.length > 0) {
    // Slack and GitHub use comma or space, Google/Airtable/Linear use space
    const separator = providerId === 'slack' ? ',' : ' ';
    url.searchParams.set('scope', scopes.join(separator));
  }

  if (state) {
    url.searchParams.set('state', state);
  }

  if (codeChallenge) {
    url.searchParams.set('code_challenge', codeChallenge);
    url.searchParams.set('code_challenge_method', codeChallengeMethod);
  }

  // Google specific offline refresh token parameters
  if (providerId === 'google-workspace') {
    url.searchParams.set('access_type', accessType || 'offline');
    url.searchParams.set('prompt', prompt || 'consent');
  }

  // Dropbox specific offline access parameter
  if (providerId === 'dropbox') {
    url.searchParams.set('token_access_type', 'offline');
  }

  return url.toString();
}

