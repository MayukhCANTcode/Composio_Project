/**
 * Scope Optimizer & Review Justification Engine
 * Maps high-level agent capabilities to minimum-privilege OAuth scopes
 * and generates audit-ready justification text for review submissions.
 */

export function optimizeScopes(appId, capabilities = []) {
  // Common intent definitions
  const results = {
    appId,
    selectedCapabilities: capabilities,
    recommendedScopes: [],
    sensitiveReviewTriggers: [],
    riskLevel: 'LOW',
    requiresPaidAudit: false,
    auditEstimate: '$0',
    justificationText: '',
    leastPrivilegeTips: []
  };

  const capSet = new Set(capabilities);

  if (appId === 'google-workspace') {
    const scopes = ['openid', 'https://www.googleapis.com/auth/userinfo.email'];
    const justifications = [];

    if (capSet.has('identity')) {
      justifications.push('Authenticate the user session and establish agent identity.');
    }
    if (capSet.has('calendar')) {
      scopes.push('https://www.googleapis.com/auth/calendar.events');
      results.sensitiveReviewTriggers.push({
        scope: 'https://www.googleapis.com/auth/calendar.events',
        tier: 'Sensitive',
        requirement: 'YouTube Demo Video & Domain Verification in Search Console'
      });
      justifications.push('Access user calendar solely to schedule and manage meetings explicitly commanded by the user during interactive chat.');
      results.leastPrivilegeTips.push('Used calendar.events instead of full https://www.googleapis.com/auth/calendar to avoid reading secondary settings.');
    }
    if (capSet.has('documents_read') || capSet.has('documents_write')) {
      scopes.push('https://www.googleapis.com/auth/drive.file');
      results.sensitiveReviewTriggers.push({
        scope: 'https://www.googleapis.com/auth/drive.file',
        tier: 'Sensitive',
        requirement: 'YouTube Demo Video & Domain Verification in Search Console'
      });
      justifications.push('Create and update files created or opened directly by our application, without accessing the rest of the user’s Drive.');
      results.leastPrivilegeTips.push('Crucial: Avoided restricted scope https://www.googleapis.com/auth/drive. Using drive.file saves you from mandatory $15k-$75k CASA Tier 2/3 third-party audit!');
    }
    if (capSet.has('email_read')) {
      scopes.push('https://www.googleapis.com/auth/gmail.readonly');
      results.sensitiveReviewTriggers.push({
        scope: 'https://www.googleapis.com/auth/gmail.readonly',
        tier: 'RESTRICTED (CASA Mandatory)',
        requirement: 'Annual CASA Tier 2/3 Third-Party Security Audit ($15,000–$75,000)'
      });
      results.requiresPaidAudit = true;
      results.auditEstimate = '$15,000 - $75,000 / year';
      justifications.push('RESTRICTED ACCESS: Required to summarize inbound user communications. Our application strictly complies with Google API Services User Data Policy, including Limited Use.');
    }

    results.recommendedScopes = scopes;
    results.riskLevel = results.requiresPaidAudit ? 'CRITICAL (CASA)' : (results.sensitiveReviewTriggers.length > 0 ? 'MODERATE (Sensitive)' : 'LOW');
    results.justificationText = `Application Justification for Google Trust & Safety Review:\n\nOur AI Assistant requests the following scopes to provide user-directed productivity automation:\n${scopes.map(s => `- ${s}`).join('\n')}\n\nPurpose & Data Handling Rationale:\n${justifications.map((j, i) => `${i + 1}. ${j}`).join('\n')}\n\nCompliance Declaration:\nData fetched via Google APIs is used strictly to fulfill user-facing instructions and is NEVER stored for third-party advertising, nor used to train generalized foundation AI models without explicit user consent. Domain ownership has been verified in Google Search Console, and our live Privacy Policy adheres to Google Limited Use requirements.`;
  }
  else if (appId === 'slack') {
    const scopes = [];
    const justifications = [];

    if (capSet.has('messages_write')) {
      scopes.push('chat:write');
      justifications.push('Post replies and agent action confirmations to public/private channels.');
    }
    if (capSet.has('messages_read')) {
      scopes.push('channels:history');
      results.sensitiveReviewTriggers.push({
        scope: 'channels:history',
        tier: 'App Directory Scrutiny',
        requirement: 'Explicit justification explaining when bot reads message history'
      });
      justifications.push('Read conversation history only when the bot is directly mentioned with @app or invoked via slash command.');
    }
    if (capSet.has('channels_read')) {
      scopes.push('channels:read');
      justifications.push('List available public channels so users can choose where reports should be dispatched.');
    }

    if (scopes.length === 0) scopes.push('chat:write', 'commands');

    results.recommendedScopes = scopes;
    results.riskLevel = results.sensitiveReviewTriggers.length > 0 ? 'MODERATE' : 'LOW';
    results.justificationText = `Slack App Directory / Admin Justification:\n\nRequested Bot Token Scopes:\n${scopes.map(s => `• ${s}`).join('\n')}\n\nUser Flow & Permission Justification:\n${justifications.map(j => `• ${j}`).join('\n')}\n\nNo broad workspace admin privileges (e.g. admin, team:read) are requested, upholding enterprise least-privilege standards.`;
  }
  else if (appId === 'meta-facebook') {
    const scopes = ['public_profile'];
    const justifications = ['Authenticate user identity.'];

    if (capSet.has('social_publish')) {
      scopes.push('pages_show_list', 'pages_manage_posts');
      results.sensitiveReviewTriggers.push({
        scope: 'pages_manage_posts',
        tier: 'Advanced Access Review',
        requirement: 'Meta Business Verification + Video Screencast Demo'
      });
      justifications.push('pages_show_list: Enable user to select which business page to connect.');
      justifications.push('pages_manage_posts: Publish marketing copy approved by the user directly to their Facebook Page.');
    }

    results.recommendedScopes = scopes;
    results.riskLevel = 'HIGH (Business Verification Required)';
    results.justificationText = `Meta App Review Submission Notes:\n\nPermissions Requested:\n${scopes.join(', ')}\n\nStep-by-Step Reviewer Guide:\n1. Log into test account provided in App Review submission.\n2. In our web dashboard, click "Connect Facebook Page".\n3. Our app lists the user’s authorized pages (pages_show_list).\n4. User generates or edits a post draft and clicks "Publish Now".\n5. The agent calls Graph API to publish the post (pages_manage_posts).\n\nA functional Data Deletion Callback URL is active, and test credentials have been verified.`;
  }
  else {
    // Standard OAuth 2.0 fallback
    results.recommendedScopes = ['read', 'write', 'offline_access'];
    results.justificationText = `Requested Scopes: ${results.recommendedScopes.join(' ')}\n\nJustification:\nRequired for delegated user authorization to read and execute actions explicitly triggered by the user in the AI agent interface.`;
  }

  return results;
}

