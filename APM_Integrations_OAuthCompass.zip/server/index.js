import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { getAllApps, getAppById, investigateApp } from './services/investigator.js';
import { optimizeScopes } from './services/scopeOptimizer.js';
import { generatePkce, generateState, validateRedirectUri, buildAuthUrl } from './services/authSimulator.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

// List all apps with optional search and filters
app.get('/api/apps', (req, res) => {
  const { q, category, difficulty, approvalRequired } = req.query;
  let apps = getAllApps();

  if (q) {
    const query = q.toLowerCase();
    apps = apps.filter(a => 
      a.name.toLowerCase().includes(query) || 
      a.id.toLowerCase().includes(query) ||
      a.category.toLowerCase().includes(query) ||
      a.archetype.toLowerCase().includes(query)
    );
  }

  if (category && category !== 'all') {
    apps = apps.filter(a => a.category.toLowerCase().includes(category.toLowerCase()));
  }

  if (difficulty && difficulty !== 'all') {
    apps = apps.filter(a => a.difficulty === parseInt(difficulty, 10));
  }

  if (approvalRequired !== undefined && approvalRequired !== 'all') {
    const isRequired = approvalRequired === 'true';
    apps = apps.filter(a => a.approvalRequired === isRequired);
  }

  res.json({
    total: apps.length,
    apps: apps.map(a => ({
      id: a.id,
      name: a.name,
      category: a.category,
      website: a.website,
      difficulty: a.difficulty,
      difficultyLabel: a.difficultyLabel,
      timeToHelloWorld: a.timeToHelloWorld,
      timeToProductionApproval: a.timeToProductionApproval,
      approvalRequired: a.approvalRequired,
      cost: a.cost,
      archetype: a.archetype,
      overview: a.overview
    }))
  });
});

// Get detailed guide for a specific app
app.get('/api/apps/:id', (req, res) => {
  const appData = getAppById(req.params.id);
  if (!appData) {
    return res.status(404).json({ error: `App "${req.params.id}" not found in guide directory.` });
  }
  res.json(appData);
});

// Live Autonomous Investigation Endpoint with Streaming Logs
app.post('/api/investigate', async (req, res) => {
  const { query } = req.body;
  if (!query || typeof query !== 'string' || !query.trim()) {
    return res.status(400).json({ error: 'Query (app name or website URL) is required.' });
  }

  // Check if client requested SSE stream
  if (req.headers.accept === 'text/event-stream') {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    try {
      const result = await investigateApp(query, (progress) => {
        res.write(`data: ${JSON.stringify(progress)}\n\n`);
      });
      res.write(`data: ${JSON.stringify({ stage: 'COMPLETE', app: result })}\n\n`);
      res.end();
    } catch (err) {
      res.write(`data: ${JSON.stringify({ stage: 'ERROR', error: err.message })}\n\n`);
      res.end();
    }
  } else {
    // Normal JSON response
    const logs = [];
    try {
      const result = await investigateApp(query, (progress) => {
        logs.push(progress);
      });
      res.json({
        success: true,
        logs,
        app: result
      });
    } catch (err) {
      res.status(500).json({ error: err.message, logs });
    }
  }
});

// Scope Optimizer & Justification Generator
app.post('/api/tools/scope-optimizer', (req, res) => {
  const { appId, capabilities } = req.body;
  if (!appId) {
    return res.status(400).json({ error: 'appId is required.' });
  }
  const result = optimizeScopes(appId, capabilities || []);
  res.json(result);
});

// Authorization URL Builder & PKCE Generator
app.post('/api/tools/build-auth-url', (req, res) => {
  const {
    providerId,
    authorizationEndpoint,
    clientId,
    redirectUri,
    scopes,
    prompt,
    accessType
  } = req.body;

  try {
    const pkce = generatePkce();
    const state = generateState();
    const validation = validateRedirectUri(providerId, redirectUri);

    const authUrl = buildAuthUrl({
      providerId,
      authorizationEndpoint,
      clientId,
      redirectUri,
      scopes: scopes || [],
      state,
      codeChallenge: pkce.codeChallenge,
      codeChallengeMethod: pkce.codeChallengeMethod,
      prompt,
      accessType
    });

    res.json({
      authUrl,
      pkce,
      state,
      redirectValidation: validation
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Validate Redirect URI
app.post('/api/tools/validate-redirect', (req, res) => {
  const { providerId, uri } = req.body;
  const validation = validateRedirectUri(providerId, uri);
  res.json(validation);
});

// Export guide as Markdown
app.get('/api/export/:id', (req, res) => {
  const appData = getAppById(req.params.id);
  if (!appData) {
    return res.status(404).send('# Error: App not found');
  }

  const markdown = `# OAuth Integration & Approval Guide: ${appData.name}

> Generated by OAuthCompass for Developers and AI Agent Builders.
> Category: ${appData.category} | Archetype: ${appData.archetype}
> Difficulty: ${appData.difficulty}/5 (${appData.difficultyLabel})
> Time to Hello World: ${appData.timeToHelloWorld} | Time to Production Approval: ${appData.timeToProductionApproval}

---

## 1. Overview
${appData.overview}

- **Developer Portal**: ${appData.developerPortal}
- **Official Documentation**: ${appData.evidence.officialDocsUrl}
- **Approval Required**: ${appData.approvalRequired ? 'YES — Requires Provider Review Before Public Distribution' : 'NO — Instant Self-Serve Distribution'}
- **Estimated Cost**: ${appData.cost}

---

## 2. Key Nuances & Gotchas
${appData.keyNuances.map(n => `- ${n}`).join('\n')}

---

## 3. Agent vs. Human Boundary
Where the AI agent automates versus where the human developer must take over:

### What the AI Agent Can Do:
${appData.agentVsHumanMatrix.agentCapabilities.map(c => `- [x] ${c}`).join('\n')}

### What the Human Developer MUST Do:
${appData.agentVsHumanMatrix.humanRequirements.map(r => `- [ ] ${r}`).join('\n')}

---

## 4. Setup Checklist
${appData.setupSteps.map(s => `### Step ${s.stepNumber}: ${s.title} (${s.agentSupport})
- Estimated Time: ${s.estimatedMinutes} minutes
- ${s.description}
${s.copyableSnippet ? `\`\`\`bash\n${s.copyableSnippet}\n\`\`\`` : ''}
${s.docsUrl ? `Reference: ${s.docsUrl}` : ''}
`).join('\n')}

---

## 5. Recommended Scopes
| Scope | Risk Level | Review Trigger | Description |
|---|---|---|---|
${appData.scopes.map(s => `| \`${s.name}\` | **${s.riskLevel.toUpperCase()}** | ${s.reviewTrigger ? '⚠️ YES' : 'None'} | ${s.description} |`).join('\n')}

---

## 6. Blocker & Troubleshooting Playbook
${appData.blockersAndSolutions.map(b => `### ⚠️ ${b.error}
- **Root Cause**: ${b.cause}
- **Fix**: ${b.solution}
`).join('\n')}

---

## 7. Grounding & Evidence
- **Verification Method**: ${appData.evidence.verifiedVia}
- **Confidence Rating**: ${appData.evidence.confidence}
- **Last Audited**: ${appData.evidence.lastVerifiedDate}
- **Audit Notes**: ${appData.evidence.notes}
`;

  res.setHeader('Content-Type', 'text/markdown');
  res.setHeader('Content-Disposition', `attachment; filename="${appData.id}-oauth-guide.md"`);
  res.send(markdown);
});

// Serve frontend build if present
const clientDist = path.join(__dirname, '../client/dist');
if (fs.existsSync(clientDist)) {
  app.use(express.static(clientDist));
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api')) return next();
    res.sendFile(path.join(clientDist, 'index.html'));
  });
}

app.listen(PORT, () => {
  console.log(`[OAuthCompass Server] Running on http://localhost:${PORT}`);
});
